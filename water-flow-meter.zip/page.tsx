"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { DropletIcon, History, AlertTriangle, Target, BarChart3, Calendar, AlertCircle } from "lucide-react"

export default function WaterMeterSystem() {
  // Estados para simulação de dados
  const [currentFlow, setCurrentFlow] = useState(2.5)
  const [totalVolume, setTotalVolume] = useState(1250.45)
  const [dailyUsage, setDailyUsage] = useState(125.5)
  const [monthlyUsage, setMonthlyUsage] = useState(3750.8)
  const [monthlyTarget, setMonthlyTarget] = useState(4000)
  const [leakDetected, setLeakDetected] = useState(false)
  const [costPerLiter, setCostPerLiter] = useState(0.003) // R$ 3,00 por m³

  // Simulação de dados históricos
  const dailyData = [65, 85, 125, 95, 115, 125.5]
  const monthlyData = [3200, 3400, 3100, 3600, 3500, 3750.8]

  // Atualização simulada de fluxo
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFlow((prev) => {
        const variation = (Math.random() - 0.5) * 0.5
        return Number((prev + variation).toFixed(2))
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Cálculo de custos
  const calculateCost = (volume: number) => {
    return (volume * costPerLiter).toFixed(2)
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-6">Sistema de Monitoramento de Água</h1>

      <Tabs defaultValue="dashboard" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
          <TabsTrigger value="analysis">Análise</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        {/* Dashboard Principal */}
        <TabsContent value="dashboard" className="space-y-4">
          {/* Medições Principais */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
                <DropletIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentFlow} L/min</div>
                <p className="text-xs text-muted-foreground">Média: 2.8 L/min</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
                <History className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalVolume.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">Desde a instalação</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Hoje</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dailyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(dailyUsage)}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Mensal</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{monthlyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(monthlyUsage)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Meta Mensal */}
          <Card>
            <CardHeader>
              <CardTitle>Meta Mensal</CardTitle>
              <CardDescription>
                {monthlyUsage} L de {monthlyTarget} L utilizados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={(monthlyUsage / monthlyTarget) * 100} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">
                {(((monthlyTarget - monthlyUsage) / monthlyTarget) * 100).toFixed(1)}% restantes para atingir a meta
              </p>
            </CardContent>
          </Card>

          {/* Alertas */}
          {leakDetected && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Vazamento Detectado!</AlertTitle>
              <AlertDescription>
                Fluxo contínuo detectado nas últimas 6 horas. Verifique suas instalações.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>

        {/* Histórico */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Consumo</CardTitle>
              <CardDescription>Últimos 6 dias de consumo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                {/* Aqui você pode adicionar um gráfico de barras ou linha */}
                <div className="flex items-end justify-between h-full">
                  {dailyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...dailyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Consumo Mensal</CardTitle>
              <CardDescription>Últimos 6 meses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {monthlyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...monthlyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Análise */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Análise de Consumo</CardTitle>
                <CardDescription>Comparação com média histórica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Consumo Atual</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>{dailyUsage.toFixed(2)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Média Diária</span>
                    <Badge>120 L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Variação</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>
                      {(((dailyUsage - 120) / 120) * 100).toFixed(1)}%
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Previsão de Consumo</CardTitle>
                <CardDescription>Baseado no histórico</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Previsão Mensal</span>
                    <Badge>{(dailyUsage * 30).toFixed(0)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Custo Estimado</span>
                    <Badge variant="outline">R$ {calculateCost(dailyUsage * 30)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Alertas */}
        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração de Alertas</CardTitle>
              <CardDescription>Defina limites para notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Alerta de Consumo Diário</span>
                <Badge>150 L</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Vazamento</span>
                <Badge>6 horas de fluxo contínuo</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Meta Mensal</span>
                <Badge>90% da meta</Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Histórico de Alertas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leakDetected && (
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Vazamento Detectado</AlertTitle>
                    <AlertDescription>Fluxo contínuo detectado - 28/02/2024 14:30</AlertDescription>
                  </Alert>
                )}
                <Alert>
                  <Target className="h-4 w-4" />
                  <AlertTitle>Meta Mensal Próxima</AlertTitle>
                  <AlertDescription>90% da meta mensal atingida - 27/02/2024 18:45</AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configurações */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Sistema</CardTitle>
              <CardDescription>Ajuste os parâmetros do medidor</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="flex justify-between items-center">
                  <span>Fator de Calibração</span>
                  <Badge>7.5 pulsos/L</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Custo por m³</span>
                  <Badge>R$ {(costPerLiter * 1000).toFixed(2)}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Meta Mensal</span>
                  <Badge>{monthlyTarget} L</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Intervalo de Leitura</span>
                  <Badge>1 segundo</Badge>
                </div>
              </div>
              <Button className="w-full">Salvar Configurações</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

