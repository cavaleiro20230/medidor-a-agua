"use client"

import WaterMeterSystem from "../page"

export default function SyntheticV0PageForDeployment() {
  return <WaterMeterSystem />
}